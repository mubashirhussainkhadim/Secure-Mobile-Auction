<?php include "include/header.php" ?>
<link type="text/css" rel="stylesheet" href="css/style.css">

<section> 
<div class="about-sec how-work new_head"><div class="container"><h1>Getting Started</h1></div></div>
</section>
<div class="mid-part">
	<div class="form-page">
		<div class="container">
			<p> </p>
		</div>
	</div>
</div>

<?php include "include/footer.php" ?>