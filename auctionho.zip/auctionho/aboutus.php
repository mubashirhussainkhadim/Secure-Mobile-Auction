<?php include "include/header.php" ?>
<link type="text/css" rel="stylesheet" href="css/style.css">

<section> 
<div class="about-sec how-work new_head" style="background-color: darkseagreen;"><div class="container"><h1>About Us</h1></div></div>

</section>
<div class="mid-part">
	<div class="form-page">
		<div class="container">
			<p>
	MobileBid gives a surely specific enjoy for each dealers and consumers through one of the maximum proactive and person pleasant web sites everywhere withinside the world. You can find out the excellent offers and gives on a huge variety of Powerful and flackship mobiles.Your dream Mobiles Lot isn't always going to stay a dream anymore.  You may want to promote your Mobiles in days with our online  Mobiles public sale..</p>

	 
 <p> MobileBid  is committed to providing quality services and products. We’re continually growing, and as our operations expand, so does our investment in the environment. </p> <br> 
  <h3> <b> <u> Quality  </u> </b></h3> 
    <p>We carry name-brand products like Samsung, LG,sony,Apple and many more . All our phones are tested for key functionality to ensure that our products are ready for market resale. </p>
	

		</div>
	</div>
</div>

<?php include "include/footer.php" ?>