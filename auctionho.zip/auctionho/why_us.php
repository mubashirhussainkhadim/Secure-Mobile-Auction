<?php include "include/header.php" ?>
<link type="text/css" rel="stylesheet" href="css/style.css">

<section> 
<div class="about-sec how-work new_head"><div class="container"><h1>Why Us</h1></div></div>
</section>
<div class="mid-part">
	<div class="form-page">
		<div class="container">
			<p>
	MobileBid offers a truly unique experience for both sellers and buyers via one of the most proactive and user friendly websites anywhere in the world. You can discover the best deals and offers on a wide range of finest Mobiles.Your dream Mobile is not going to remain a dream anymore. MobileBid is here to turn it into a cherish-able reality. You could sell your Mobile in days with our online ebay style Mobile auction. All the excitement of a traditional auction but online. </p>
		</div>
	</div>
</div>

<?php include "include/footer.php" ?>